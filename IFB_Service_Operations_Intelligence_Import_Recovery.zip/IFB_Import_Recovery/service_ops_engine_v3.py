"""Analytics engine for the Service Operations Intelligence demonstration.
No network calls are made by this module. Workbooks are processed in memory within the app session.
"""
from __future__ import annotations

import io
import re
import textwrap
from collections import Counter
from datetime import date, datetime, time, timedelta
from typing import Any, Dict, List, Optional, Sequence, Tuple

import pandas as pd

DATE_FMT = "%Y-%m-%d"
PART_COLUMNS = {
    "spare", "sparedesc", "additive", "additivedesc", "accessories", "accessoriesdesc"
}


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    if isinstance(value, (int,)):
        return str(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    s = str(value).strip()
    if s.lower() in {"nan", "nat", "none", "null"}:
        return ""
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return s


def norm(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean_text(value).lower())


def parse_dt(value: Any) -> Optional[pd.Timestamp]:
    if value is None or clean_text(value) == "":
        return None
    try:
        dt = pd.to_datetime(value, errors="coerce")
        if pd.isna(dt):
            return None
        dt = pd.Timestamp(dt)
        if dt.year <= 1900:
            return None
        return dt
    except Exception:
        return None


def _parse_report_range(text: str) -> Tuple[Optional[pd.Timestamp], Optional[pd.Timestamp]]:
    # Examples: "Date Range :10/1/2026 12:00:00 AM - 10/22/2026 12:00:00 AM"
    match = re.search(r"date\s*range\s*:\s*(.+?)\s+-\s+(.+)$", text, flags=re.I)
    if not match:
        return None, None
    start = parse_dt(match.group(1).strip())
    end = parse_dt(match.group(2).strip())
    return start, end


def _filename_timestamp(name: str) -> Optional[pd.Timestamp]:
    match = re.search(r"(20\d{2}-\d{2}-\d{2})T(\d{6})(?:\.(\d+))?", name)
    if not match:
        return None
    date_part, time_part, fractional = match.groups()
    fmt = "%Y-%m-%dT%H%M%S"
    stamp = f"{date_part}T{time_part}"
    try:
        dt = datetime.strptime(stamp, fmt)
        if fractional:
            micro = (fractional + "000000")[:6]
            dt = dt.replace(microsecond=int(micro))
        return pd.Timestamp(dt)
    except ValueError:
        return None


def _detect_header(preview: pd.DataFrame) -> Optional[int]:
    for idx in range(min(len(preview), 20)):
        vals = {norm(v) for v in preview.iloc[idx].tolist() if clean_text(v)}
        has_ticket = bool(vals & {"ticketno", "ticketnumber", "ticket"})
        has_context = bool(vals & {"calltype", "status", "feedback", "daysold", "repeatcallflag"})
        if has_ticket and has_context:
            return idx
    return None


def _classify(df: pd.DataFrame) -> str:
    columns = {norm(c) for c in df.columns}
    if "ticketno" not in columns and "ticketnumber" not in columns:
        return "unknown"
    if "feedback" in columns and "feedbackdate" in columns:
        return "customer_satisfaction"
    # Soft Closure (All Status) exports are used to reconcile calls closed by the snapshot time.
    if "softclosuredate" in columns and "status" in columns:
        return "soft_closure"
    # Calls Registered exports also contain Days Old and repeatcall flag, so test them first.
    if "callbookdate" in columns and ("assignon" in columns or "closedtime" in columns):
        return "calls_registered"
    if "daysold" in columns and "repeatcallflag" in columns:
        return "pending_calls"
    return "unknown"


def parse_report(filename: str, file_bytes: bytes, upload_order: int = 0) -> Dict[str, Any]:
    """Read one uploaded workbook and classify it using its headers and metadata."""
    preview = pd.read_excel(io.BytesIO(file_bytes), sheet_name=0, header=None, nrows=15, dtype=object)
    header_idx = _detect_header(preview)
    if header_idx is None:
        raise ValueError("Could not locate a report header row containing Ticket No and report fields.")

    metadata = ""
    for _, row in preview.iterrows():
        for cell in row.tolist():
            val = clean_text(cell)
            if val and "date range" in val.lower():
                metadata = val
                break
        if metadata:
            break
    period_start, period_end = _parse_report_range(metadata)

    df = pd.read_excel(io.BytesIO(file_bytes), sheet_name=0, header=header_idx, dtype=object)
    # Remove only fully empty / unnamed filler columns. Keep all meaningful source columns.
    drop_cols = []
    for c in df.columns:
        if clean_text(c).lower().startswith("unnamed") and df[c].isna().all():
            drop_cols.append(c)
    if drop_cols:
        df = df.drop(columns=drop_cols)
    df.columns = [clean_text(c) if clean_text(c) else f"Column_{i+1}" for i, c in enumerate(df.columns)]
    df = df.dropna(how="all").reset_index(drop=True)
    report_type = _classify(df)
    if report_type == "unknown":
        raise ValueError("The file was read, but its report type could not be identified. Expected Pending Calls, Calls Registered, Soft Closure, or Customer Satisfaction.")

    filename_dt = _filename_timestamp(filename)
    if filename_dt is not None:
        snapshot_dt = filename_dt
        snapshot_source = "timestamp in filename"
    elif period_end is not None:
        # The report period end is a date label, not necessarily the real export time.
        snapshot_dt = pd.Timestamp(period_end.date()) + pd.Timedelta(hours=23, minutes=59)
        snapshot_source = "date range (export time unknown)"
    else:
        snapshot_dt = pd.Timestamp.now().floor("min")
        snapshot_source = "upload time fallback (export time unknown)"

    return {
        "filename": filename,
        "bytes": len(file_bytes),
        "report_type": report_type,
        "df": df,
        "header_row_excel": header_idx + 1,
        "metadata": metadata,
        "period_start": period_start,
        "period_end": period_end,
        "snapshot_dt": snapshot_dt,
        "snapshot_source": snapshot_source,
        "upload_order": upload_order,
        "rows": len(df),
    }


def find_col(df: pd.DataFrame, aliases: Sequence[str]) -> Optional[str]:
    mapping = {norm(c): c for c in df.columns}
    for alias in aliases:
        key = norm(alias)
        if key in mapping:
            return mapping[key]
    return None


def choose_value(series: pd.Series) -> Any:
    values = [clean_text(v) for v in series.tolist()]
    values = [v for v in values if v]
    if not values:
        return ""
    counts = Counter(values)
    # Counter preserves first-seen order for ties.
    return counts.most_common(1)[0][0]


def join_values(series: pd.Series, max_len: int = 300) -> str:
    vals = []
    seen = set()
    for value in series.tolist():
        value = clean_text(value)
        if value and value not in seen:
            vals.append(value)
            seen.add(value)
    out = " | ".join(vals)
    if len(out) > max_len:
        return out[: max_len - 3] + "..."
    return out


def get_ticket_col(df: pd.DataFrame) -> Optional[str]:
    return find_col(df, ["Ticket No", "TicketNo", "Ticket Number", "Ticket"])


# These call types are intentionally excluded from pending-call ranking and pending KPIs.
# The source exports may call the first type "COURTESY CALL" or "COURTESY VISIT";
# the second can appear as "DEALER DEFECTIVE" or "DEALER DEFECTIVE REQUEST".
_EXCLUDED_PENDING_CALL_TYPE_MARKERS = ("courtesy", "dealerdefective")


def excluded_pending_call_type_mask(df: pd.DataFrame) -> pd.Series:
    """Return True for courtesy and dealer-defective rows in a pending-call export."""
    call_type_col = find_col(df, ["Call Type", "CallType"])
    if call_type_col is None:
        return pd.Series(False, index=df.index, dtype=bool)
    return df[call_type_col].map(
        lambda value: any(marker in norm(value) for marker in _EXCLUDED_PENDING_CALL_TYPE_MARKERS)
    ).astype(bool)


def filter_pending_call_types(df: pd.DataFrame) -> pd.DataFrame:
    """Exclude Courtesy and Dealer Defective calls from pending-call analysis."""
    mask = excluded_pending_call_type_mask(df)
    return df.loc[~mask].copy()


def distinct_ticket_count(df: pd.DataFrame) -> int:
    ticket_col = get_ticket_col(df)
    if not ticket_col:
        return len(df)
    return len({clean_text(v) for v in df[ticket_col].tolist() if clean_text(v)})


def summarize_pending_rows(df: pd.DataFrame) -> pd.DataFrame:
    """One record per ticket; component/spare fields are consolidated, not discarded."""
    ticket_col = get_ticket_col(df)
    if not ticket_col:
        return pd.DataFrame(columns=list(df.columns))
    working = df.copy()
    working["__ticket_key"] = working[ticket_col].map(clean_text)
    working = working[working["__ticket_key"] != ""].copy()
    part_norms = PART_COLUMNS
    columns = [c for c in working.columns if c != "__ticket_key"]
    records = []
    for key, group in working.groupby("__ticket_key", sort=False, dropna=False):
        rec: Dict[str, Any] = {}
        for col in columns:
            if norm(col) in part_norms:
                rec[col] = join_values(group[col])
            elif norm(col) == "daysold":
                # A ticket can occupy multiple component rows; use its greatest age only.
                numeric_ages = pd.to_numeric(group[col], errors="coerce").dropna()
                rec[col] = int(numeric_ages.max()) if not numeric_ages.empty else ""
            elif norm(col) == "callbookdate":
                # When Days Old is blank, the oldest valid booking date is the age fallback.
                parsed_dates = pd.to_datetime(group[col], errors="coerce", format="mixed").dropna()
                rec[col] = parsed_dates.min() if not parsed_dates.empty else choose_value(group[col])
            else:
                rec[col] = choose_value(group[col])
        rec[ticket_col] = clean_text(key)
        rec["Source Row Count"] = len(group)
        records.append(rec)
    return pd.DataFrame(records)


def _get_value(row: pd.Series, aliases: Sequence[str]) -> str:
    for alias in aliases:
        col = find_col(pd.DataFrame(columns=row.index), [alias])
        if col is not None:
            return clean_text(row.get(col, ""))
    return ""


def enrich_pending(pending_df: pd.DataFrame, snapshot_dt: pd.Timestamp) -> pd.DataFrame:
    df = pending_df.copy()
    aliases = {
        "Ticket No": ["Ticket No", "TicketNo", "Ticket Number", "Ticket"],
        "Franchise Name": ["Franchise Name", "FrName", "Franchise"],
        "Customer Name": ["Customer Name"],
        "Service Executive Name": ["Service Executive Name", "Branch Exe Name", "Executive Name"],
        "Technician Name": ["Technician Name"],
        "Days Old": ["Days Old"],
        "Escalation Level": ["ESCLATION LEVEL", "Escalation Level", "Escalation"],
        "Scheduled Date": ["Scheduled date", "Schedule Date", "Scheduled Date"],
        "Status": ["Status"],
        "Repeat Call Flag": ["repeatcall flag", "Repeat Call Flag"],
        "Call Type": ["Call Type"],
        "Product": ["Product"],
        "Model": ["Model"],
        "Customer Code": ["Customer Code"],
        "Call Book Date": ["Call Book Date"],
    }
    for standard, choices in aliases.items():
        col = find_col(df, choices)
        df[standard] = df[col].map(clean_text) if col else ""
    ages = pd.to_numeric(df["Days Old"], errors="coerce")
    call_dates = pd.to_datetime(df["Call Book Date"], errors="coerce", format="mixed")
    calc_ages = (snapshot_dt.normalize() - call_dates.dt.normalize()).dt.days
    calc_ages = calc_ages.where(call_dates.dt.year > 1900)
    ages = ages.fillna(calc_ages).fillna(0).clip(lower=0)
    df["Days Old"] = ages.astype(int)
    sched = pd.to_datetime(df["Scheduled Date"], errors="coerce", format="mixed")
    sched = sched.where(sched.dt.year > 1900)
    sched_overdue = (sched < snapshot_dt).fillna(False)

    # Keep source escalation/repeat values as descriptive indicators only; they do not affect ordering.
    df["Has Escalation"] = df["Escalation Level"].map(
        lambda v: bool(clean_text(v)) and norm(v) not in {"na", "none", "nan", "0"}
    )
    df["Is Repeat Call"] = df["Repeat Call Flag"].map(
        lambda v: norm(v) in {"x", "yes", "y", "true", "1", "repeat", "repeatcall"}
    )
    df["Missing Executive"] = df["Service Executive Name"].map(lambda v: not bool(clean_text(v)))
    df["Missing Technician"] = df["Technician Name"].map(lambda v: not bool(clean_text(v)))
    df["Snapshot As Of"] = snapshot_dt.strftime("%Y-%m-%d %H:%M")
    df["Scheduled Overdue"] = sched_overdue.astype(bool)
    # ONLY sort key: Days Old descending. Equal-age calls preserve their source order.
    # There is no score, weighting, escalation/repeat/schedule tie-breaker, or colour band.
    df = df.sort_values(by="Days Old", ascending=False, kind="stable", na_position="last").reset_index(drop=True)
    df.insert(0, "Order", range(1, len(df) + 1))
    return df


def _group_ticket_ids(df: pd.DataFrame) -> set:
    col = get_ticket_col(df)
    if not col:
        return set()
    return {clean_text(v) for v in df[col].tolist() if clean_text(v)}


def _pending_status_map(df: pd.DataFrame) -> Dict[str, str]:
    col_ticket = get_ticket_col(df)
    col_status = find_col(df, ["Status"])
    if not col_ticket:
        return {}
    if not col_status:
        return {clean_text(t): "" for t in df[col_ticket] if clean_text(t)}
    out = {}
    for ticket, group in df.groupby(df[col_ticket].map(clean_text), sort=False):
        if ticket:
            out[clean_text(ticket)] = choose_value(group[col_status])
    return out


def _valid_datetime_series(series: pd.Series) -> pd.Series:
    """Parse mixed Excel timestamps while treating 1900 placeholder dates as missing."""
    parsed = pd.to_datetime(series, errors="coerce", format="mixed")
    try:
        return parsed.where(parsed.notna() & (parsed.dt.year > 1900))
    except Exception:
        return pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")


def soft_closure_ticket_ids_as_of(reports: List[Dict[str, Any]], snapshot_dt: pd.Timestamp) -> set:
    """Ticket IDs with a soft-closure event at or before the pending snapshot time."""
    closed_ids = set()
    for report in reports:
        if report.get("report_type") != "soft_closure":
            continue
        df = report.get("df", pd.DataFrame())
        ticket_col = get_ticket_col(df)
        if not ticket_col or df.empty:
            continue
        soft_col = find_col(df, ["Soft Closure Date", "Soft Closed Date", "SoftClosureDate", "Closure Date"])
        closed_col = find_col(df, ["ClosedDate", "Closed Date", "Closed Time", "Closed Timestamp"])
        if soft_col:
            event_ts = _valid_datetime_series(df[soft_col])
        else:
            event_ts = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns]")
        if closed_col:
            event_ts = event_ts.fillna(_valid_datetime_series(df[closed_col]))
        for idx, row in df.iterrows():
            ticket = clean_text(row.get(ticket_col, ""))
            if not ticket:
                continue
            event_time = event_ts.loc[idx] if idx in event_ts.index else pd.NaT
            if pd.notna(event_time):
                if pd.Timestamp(event_time) <= pd.Timestamp(snapshot_dt):
                    closed_ids.add(ticket)
            else:
                # Conservative fallback only when event timestamps are absent: use report-period timing.
                period_end = report.get("period_end")
                if period_end is not None and pd.Timestamp(period_end).date() < pd.Timestamp(snapshot_dt).date():
                    closed_ids.add(ticket)
                elif (period_end is not None and pd.Timestamp(period_end).date() == pd.Timestamp(snapshot_dt).date()
                      and pd.Timestamp(report.get("snapshot_dt")) <= pd.Timestamp(snapshot_dt)):
                    closed_ids.add(ticket)
    return closed_ids


def active_pending_data(report: Dict[str, Any], reports: Optional[List[Dict[str, Any]]] = None) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    """Return one row per active pending ticket plus its source rows and exclusion stats.

    Exclusions: Courtesy / Dealer Defective call types, tickets soft-closed at or before
    the snapshot timestamp, and tickets whose status is Negative Response from Customer.
    """
    reports = reports or [report]
    source_df = report.get("df", pd.DataFrame())
    by_type = filter_pending_call_types(source_df)
    ticket_col = get_ticket_col(by_type)
    if not ticket_col:
        return pd.DataFrame(columns=list(by_type.columns)), by_type.iloc[0:0].copy(), {
            "source_distinct_tickets": 0, "active_tickets": 0,
            "soft_closed_tickets": 0, "negative_response_tickets": 0,
            "excluded_ticket_ids": set(), "active_ticket_ids": set(),
        }

    grouped = summarize_pending_rows(by_type)
    grouped_ticket_col = get_ticket_col(grouped)
    source_ids = {clean_text(v) for v in grouped[grouped_ticket_col].tolist() if clean_text(v)}

    # If any source row for a ticket carries a negative-response status, exclude the whole ticket.
    status_col_raw = find_col(by_type, ["Status"])
    negative_ids = set()
    if status_col_raw:
        negative_rows = by_type[by_type[status_col_raw].map(lambda v: "negativeresponse" in norm(v))]
        negative_ids = {clean_text(v) for v in negative_rows[ticket_col].tolist() if clean_text(v)}

    snapshot_dt = pd.Timestamp(report.get("snapshot_dt"))
    soft_closed_ids = soft_closure_ticket_ids_as_of(reports, snapshot_dt)
    soft_matched = source_ids & soft_closed_ids
    negative_only = negative_ids - soft_matched
    excluded_ids = soft_matched | negative_ids
    active_ids = source_ids - excluded_ids
    active_grouped = grouped[grouped[grouped_ticket_col].map(clean_text).isin(active_ids)].copy().reset_index(drop=True)
    source_ticket_ids = by_type[ticket_col].map(clean_text)
    active_source_rows = by_type[source_ticket_ids.isin(active_ids)].copy().reset_index(drop=True)

    return active_grouped, active_source_rows, {
        "source_distinct_tickets": len(source_ids),
        "active_tickets": len(active_ids),
        "soft_closed_tickets": len(soft_matched),
        "negative_response_tickets": len(negative_only),
        "excluded_ticket_ids": excluded_ids,
        "active_ticket_ids": active_ids,
        "negative_response_ids": negative_only,
        "soft_closed_ids": soft_matched,
    }


def snapshot_comparison(previous: Optional[Dict[str, Any]], current: Dict[str, Any],
                        reports: Optional[List[Dict[str, Any]]] = None) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Compare only tickets active at each snapshot, using closure timestamps when available."""
    reports = reports or [current] + ([previous] if previous else [])
    cur_grouped, _, _ = active_pending_data(current, reports)
    cur_ticket = get_ticket_col(cur_grouped)
    if not cur_ticket:
        return pd.DataFrame(), {"new": 0, "continuing": 0, "missing": 0, "status_changed": 0, "age_increased": 0}
    cur_map = {}
    age_col_cur = find_col(cur_grouped, ["Days Old"])
    exec_col_cur = find_col(cur_grouped, ["Service Executive Name"])
    franchise_col_cur = find_col(cur_grouped, ["Franchise Name", "Franchise"])
    status_col_cur = find_col(cur_grouped, ["Status"])
    for _, r in cur_grouped.iterrows():
        key = clean_text(r.get(cur_ticket, ""))
        if not key:
            continue
        cur_map[key] = {
            "status": clean_text(r.get(status_col_cur, "")) if status_col_cur else "",
            "age": pd.to_numeric(pd.Series([r.get(age_col_cur, 0)]), errors="coerce").fillna(0).iloc[0] if age_col_cur else 0,
            "executive": clean_text(r.get(exec_col_cur, "")) if exec_col_cur else "",
            "franchise": clean_text(r.get(franchise_col_cur, "")) if franchise_col_cur else "",
        }

    prev_map = {}
    if previous:
        prev_grouped, _, _ = active_pending_data(previous, reports)
        prev_tcol = get_ticket_col(prev_grouped)
        age_col_prev = find_col(prev_grouped, ["Days Old"])
        exec_col_prev = find_col(prev_grouped, ["Service Executive Name"])
        franchise_col_prev = find_col(prev_grouped, ["Franchise Name", "Franchise"])
        status_col_prev = find_col(prev_grouped, ["Status"])
        for _, r in prev_grouped.iterrows():
            key = clean_text(r.get(prev_tcol, ""))
            if not key:
                continue
            prev_map[key] = {
                "status": clean_text(r.get(status_col_prev, "")) if status_col_prev else "",
                "age": pd.to_numeric(pd.Series([r.get(age_col_prev, 0)]), errors="coerce").fillna(0).iloc[0] if age_col_prev else 0,
                "executive": clean_text(r.get(exec_col_prev, "")) if exec_col_prev else "",
                "franchise": clean_text(r.get(franchise_col_prev, "")) if franchise_col_prev else "",
            }

    prev_ids, cur_ids = set(prev_map), set(cur_map)
    records = []
    status_changed = age_increased = 0
    for key in sorted(prev_ids | cur_ids):
        prev_item = prev_map.get(key)
        cur_item = cur_map.get(key)
        if prev_item and cur_item:
            status_diff = bool(prev_item["status"] and cur_item["status"] and norm(prev_item["status"]) != norm(cur_item["status"]))
            age_diff = float(cur_item["age"]) > float(prev_item["age"])
            status_changed += int(status_diff)
            age_increased += int(age_diff)
            if status_diff and age_diff:
                movement = "Present; status changed and age increased"
            elif status_diff:
                movement = "Present; status changed"
            elif age_diff:
                movement = "Present; age increased"
            else:
                movement = "Present in both snapshots"
        elif cur_item:
            movement = "Newly present in latest pending report"
        else:
            movement = "No longer present in latest report (not proof of closure)"
        records.append({
            "Ticket No": key,
            "Movement": movement,
            "Previous Status": prev_item["status"] if prev_item else "",
            "Current Status": cur_item["status"] if cur_item else "",
            "Previous Days Old": prev_item["age"] if prev_item else "",
            "Current Days Old": cur_item["age"] if cur_item else "",
            "Previous Executive": prev_item["executive"] if prev_item else "",
            "Current Executive": cur_item["executive"] if cur_item else "",
            "Previous Franchise": prev_item["franchise"] if prev_item else "",
            "Current Franchise": cur_item["franchise"] if cur_item else "",
        })
    counts = {
        "new": len(cur_ids - prev_ids),
        "continuing": len(cur_ids & prev_ids),
        "missing": len(prev_ids - cur_ids),
        "status_changed": status_changed,
        "age_increased": age_increased,
    }
    return pd.DataFrame(records), counts

def _latest_by_type(reports: List[Dict[str, Any]], report_type: str, on_or_before: Optional[date] = None) -> Optional[Dict[str, Any]]:
    items = [r for r in reports if r["report_type"] == report_type]
    if on_or_before:
        bound = pd.Timestamp(datetime.combine(on_or_before, time.max))
        eligible = [r for r in items if r["snapshot_dt"] <= bound or (r["period_end"] is not None and r["period_end"].date() <= on_or_before)]
        if eligible:
            items = eligible
        elif items:
            # No older report available; return latest available and let the UI identify its period.
            pass
    return sorted(items, key=lambda r: (r["snapshot_dt"], r["upload_order"]))[-1] if items else None


def analyze_reports(reports: List[Dict[str, Any]], analysis_date: Optional[date] = None) -> Dict[str, Any]:
    pending_reports = sorted(
        [r for r in reports if r["report_type"] == "pending_calls"],
        key=lambda r: (r["snapshot_dt"], r["upload_order"]),
    )
    if not pending_reports:
        raise ValueError("Upload at least one Pending Call report to generate the oldest-first pending-call list.")
    if analysis_date is None:
        analysis_date = pending_reports[-1]["snapshot_dt"].date()
    bound = pd.Timestamp(datetime.combine(analysis_date, time.max))
    eligible_pending = [r for r in pending_reports if r["snapshot_dt"] <= bound]
    if not eligible_pending:
        raise ValueError("No Pending Call snapshot exists on or before the selected analysis date. Choose a later date or upload an earlier report.")
    current = eligible_pending[-1]
    prev_candidates = [r for r in pending_reports if (r["snapshot_dt"], r["upload_order"]) < (current["snapshot_dt"], current["upload_order"])]
    previous = prev_candidates[-1] if prev_candidates else None

    current_type_rows = filter_pending_call_types(current["df"])
    current_ticket_df, current_eligible_rows, current_exclusion_stats = active_pending_data(current, reports)
    # Pending Reason is intentionally excluded from analysis: it is often blank/inconsistent in source exports.
    current_ticket_df = current_ticket_df.drop(columns=[c for c in current_ticket_df.columns if norm(c) == "pendingreason"], errors="ignore")
    priorities = enrich_pending(current_ticket_df, current["snapshot_dt"])
    top20 = priorities.head(20).copy()
    executive_name_col = find_col(top20, ["Service Executive Name"])
    if len(top20):
        if executive_name_col:
            top20_executives = top20[executive_name_col].map(lambda v: clean_text(v) or "Unspecified")
        else:
            top20_executives = pd.Series(["Unspecified"] * len(top20), index=top20.index)
        top20_exec_counts = top20_executives.value_counts()
        top20["Executive % of Top 20"] = top20_executives.map(top20_exec_counts).astype(float) * 100.0 / len(top20)
        top20_executive_summary = pd.DataFrame({"Executive": top20_exec_counts.index, "Top 20 Calls": top20_exec_counts.values})
        top20_executive_summary["Share of Top 20 (%)"] = top20_executive_summary["Top 20 Calls"] * 100.0 / len(top20)
        top20_executive_summary = top20_executive_summary.sort_values(["Top 20 Calls", "Executive"], ascending=[False, True], kind="stable").reset_index(drop=True)
    else:
        top20["Executive % of Top 20"] = pd.Series(dtype=float)
        top20_executive_summary = pd.DataFrame(columns=["Executive", "Top 20 Calls", "Share of Top 20 (%)"])
    comparisons, movement_counts = snapshot_comparison(previous, current, reports)

    csat_report = _latest_by_type(reports, "customer_satisfaction", analysis_date)
    reg_report = _latest_by_type(reports, "calls_registered", analysis_date)
    csat = csat_report["df"].copy() if csat_report else pd.DataFrame()
    registered = reg_report["df"].copy() if reg_report else pd.DataFrame()

    # If Calls Registered spans multiple days, report only the selected analysis date when booking date exists.
    registered_for_day = registered.copy()
    reg_date_col = find_col(registered_for_day, ["Call Book Date"]) if not registered_for_day.empty else None
    registered_date_coverage = ""
    registered_date_covered = False
    if reg_report is not None:
        meta_start = reg_report["period_start"].date() if reg_report["period_start"] is not None else None
        meta_end = reg_report["period_end"].date() if reg_report["period_end"] is not None else None
        if meta_start and meta_end and meta_start <= analysis_date <= meta_end:
            registered_date_covered = True
    if reg_date_col:
        reg_dates = pd.to_datetime(registered_for_day[reg_date_col], errors="coerce", format="mixed")
        valid_dates = reg_dates.dropna()
        if not valid_dates.empty:
            min_date, max_date = valid_dates.min().date(), valid_dates.max().date()
            registered_date_coverage = f"Bookings {min_date:%d %b %Y}–{max_date:%d %b %Y}"
            if not registered_date_covered and not (reg_report and reg_report["period_start"] and reg_report["period_end"]):
                registered_date_covered = min_date <= analysis_date <= max_date
            mask = reg_dates.dt.date == analysis_date
            registered_for_day = registered_for_day.loc[mask.fillna(False)].copy() if registered_date_covered else registered_for_day.iloc[0:0].copy()
    elif not registered_date_covered:
        registered_for_day = registered_for_day.iloc[0:0].copy()

    csat_feedback_col = find_col(csat, ["FeedBack", "Feedback", "Feedback Score"]) if not csat.empty else None
    csat_summary = pd.DataFrame(columns=["Feedback", "Count", "Share %"])
    csat_metrics = {
        "total": 0, "source_rows": 0, "blank": 0,
        "happy": 0, "ok": 0, "not_happy": 0,
        "happy_pct": None, "not_happy_pct": None,
        "css_pct": None, "css_pct_rounded": None,
    }
    if csat_feedback_col:
        feedback = csat[csat_feedback_col].map(lambda v: clean_text(v).upper())
        # CSS denominator is actual nonblank feedback responses, not the number of happy responses.
        # Formula supplied by the user: (HAPPY - NOT HAPPY) / TOTAL FEEDBACK * 100.
        valid_feedback = feedback[feedback != ""]
        counts = valid_feedback.value_counts()
        total = int(len(valid_feedback))
        csat_summary = pd.DataFrame([
            {"Feedback": k, "Count": int(v), "Share %": round(100 * int(v) / total, 2) if total else 0}
            for k, v in counts.items()
        ])
        happy_count = int((valid_feedback == "HAPPY").sum())
        ok_count = int((valid_feedback == "OK").sum())
        not_happy_count = int((valid_feedback == "NOT HAPPY").sum())
        css_pct = (100 * (happy_count - not_happy_count) / total) if total else None
        csat_metrics = {
            "total": total,
            "source_rows": int(len(csat)),
            "blank": int((feedback == "").sum()),
            "happy": happy_count,
            "ok": ok_count,
            "not_happy": not_happy_count,
            "happy_pct": round(100 * happy_count / total, 2) if total else None,
            "not_happy_pct": round(100 * not_happy_count / total, 2) if total else None,
            "css_pct": round(css_pct, 2) if css_pct is not None else None,
            # Management image rounds CSS to the nearest whole percentage point.
            "css_pct_rounded": int(round(css_pct)) if css_pct is not None else None,
        }

    # Compare the latest Customer Satisfaction snapshot with the previous available snapshot.
    # Shares show feedback mix; CSS itself uses (Happy - Not Happy) / total nonblank feedback × 100.
    csat_items = sorted(
        [r for r in reports if r["report_type"] == "customer_satisfaction" and
         (r["snapshot_dt"] <= bound or (r["period_end"] is not None and r["period_end"].date() <= analysis_date))],
        key=lambda r: (r["snapshot_dt"], r["upload_order"]),
    )
    csat_previous_report = None
    if csat_report is not None:
        prior_items = [r for r in csat_items if (r["snapshot_dt"], r["upload_order"]) < (csat_report["snapshot_dt"], csat_report["upload_order"])]
        if prior_items:
            csat_previous_report = prior_items[-1]
    csat_comparison = pd.DataFrame(columns=["Feedback", "Previous Count", "Current Count", "Count Change", "Previous Share %", "Current Share %", "Share Change (pp)"])
    csat_movement = {"previous_rows": None, "current_rows": len(csat), "new_tickets": None, "missing_tickets": None, "happy_delta_pp": None, "not_happy_delta_pp": None, "css_delta_pp": None}
    if csat_previous_report is not None:
        prev_df = csat_previous_report["df"].copy()
        prev_fb_col = find_col(prev_df, ["FeedBack", "Feedback", "Feedback Score"])
        current_fb = csat[csat_feedback_col].map(lambda v: clean_text(v).upper()) if csat_feedback_col else pd.Series(dtype=str)
        prev_fb = prev_df[prev_fb_col].map(lambda v: clean_text(v).upper()) if prev_fb_col else pd.Series(dtype=str)
        prev_valid = prev_fb[prev_fb != ""]
        current_valid = current_fb[current_fb != ""]
        prev_total, curr_total = len(prev_valid), len(current_valid)
        prev_counts, curr_counts = prev_valid.value_counts(), current_valid.value_counts()
        feedback_labels = sorted(set(prev_counts.index.tolist()) | set(curr_counts.index.tolist()))
        comp_rows = []
        for label in feedback_labels:
            p_count, c_count = int(prev_counts.get(label, 0)), int(curr_counts.get(label, 0))
            p_share = round(100 * p_count / prev_total, 2) if prev_total else 0.0
            c_share = round(100 * c_count / curr_total, 2) if curr_total else 0.0
            comp_rows.append({"Feedback": label or "Blank", "Previous Count": p_count, "Current Count": c_count,
                              "Count Change": c_count - p_count, "Previous Share %": p_share,
                              "Current Share %": c_share, "Share Change (pp)": round(c_share - p_share, 2)})
        csat_comparison = pd.DataFrame(comp_rows).sort_values("Current Count", ascending=False).reset_index(drop=True) if comp_rows else pd.DataFrame(columns=["Feedback", "Previous Count", "Current Count", "Count Change", "Previous Share %", "Current Share %", "Share Change (pp)"])
        prev_ticket_col, curr_ticket_col = get_ticket_col(prev_df), get_ticket_col(csat)
        prev_ids = {clean_text(v) for v in prev_df[prev_ticket_col].tolist() if clean_text(v)} if prev_ticket_col else set()
        curr_ids = {clean_text(v) for v in csat[curr_ticket_col].tolist() if clean_text(v)} if curr_ticket_col else set()
        prev_happy_share = 100 * (prev_valid == "HAPPY").sum() / prev_total if prev_total else None
        curr_happy_share = 100 * (current_valid == "HAPPY").sum() / curr_total if curr_total else None
        prev_not_happy_share = 100 * (prev_valid == "NOT HAPPY").sum() / prev_total if prev_total else None
        curr_not_happy_share = 100 * (current_valid == "NOT HAPPY").sum() / curr_total if curr_total else None
        prev_css = 100 * (((prev_valid == "HAPPY").sum()) - ((prev_valid == "NOT HAPPY").sum())) / prev_total if prev_total else None
        curr_css = 100 * (((current_valid == "HAPPY").sum()) - ((current_valid == "NOT HAPPY").sum())) / curr_total if curr_total else None
        csat_movement = {
            "previous_rows": prev_total, "current_rows": curr_total,
            "new_tickets": len(curr_ids - prev_ids), "missing_tickets": len(prev_ids - curr_ids),
            "happy_delta_pp": round(round(curr_happy_share, 2) - round(prev_happy_share, 2), 2) if prev_happy_share is not None and curr_happy_share is not None else None,
            "not_happy_delta_pp": round(round(curr_not_happy_share, 2) - round(prev_not_happy_share, 2), 2) if prev_not_happy_share is not None and curr_not_happy_share is not None else None,
            "css_delta_pp": round(curr_css - prev_css, 2) if prev_css is not None and curr_css is not None else None,
        }

    def count_distinct(df: pd.DataFrame) -> int:
        c = get_ticket_col(df)
        return len({clean_text(v) for v in df[c].tolist() if clean_text(v)}) if c else len(df)

    reg_ticket_col = get_ticket_col(registered_for_day) if not registered_for_day.empty else None
    registered_count = count_distinct(registered_for_day) if registered_date_covered else None
    status_col = find_col(priorities, ["Status"])
    status_summary = priorities[status_col].map(lambda v: clean_text(v) or "Unspecified").value_counts().rename_axis("Status").reset_index(name="Unique Tickets") if status_col else pd.DataFrame(columns=["Status", "Unique Tickets"])
    call_type_col = find_col(priorities, ["Call Type"])
    call_type_summary = priorities[call_type_col].map(lambda v: clean_text(v) or "Unspecified").value_counts().rename_axis("Call Type").reset_index(name="Unique Tickets") if call_type_col else pd.DataFrame(columns=["Call Type", "Unique Tickets"])
    franchise_col = find_col(priorities, ["Franchise Name"])
    if franchise_col:
        _fr = priorities.copy()
        _fr["Franchise"] = _fr[franchise_col].map(lambda v: clean_text(v) or "Unspecified")
        franchise_summary = _fr.groupby("Franchise", dropna=False).agg(
            **{"Pending Tickets": ("Ticket No", "count"),
               "Aged >2 Days": ("Days Old", lambda s: int((pd.to_numeric(s, errors="coerce").fillna(0) > 2).sum())),
               "Aged 7+ Days": ("Days Old", lambda s: int((pd.to_numeric(s, errors="coerce").fillna(0) >= 7).sum())),
               "Escalated Tickets": ("Has Escalation", lambda s: int(s.astype(bool).sum())),
               "Repeat-call Flags": ("Is Repeat Call", lambda s: int(s.astype(bool).sum())),
               "Average Age (days)": ("Days Old", lambda s: round(pd.to_numeric(s, errors="coerce").fillna(0).mean(), 1)),
            }
        ).reset_index().sort_values(["Aged >2 Days", "Pending Tickets"], ascending=False).reset_index(drop=True)
    else:
        franchise_summary = pd.DataFrame(columns=["Franchise", "Pending Tickets", "Aged >2 Days", "Aged 7+ Days", "Escalated Tickets", "Repeat-call Flags", "Average Age (days)"])
    exec_col = find_col(priorities, ["Service Executive Name"])
    if exec_col:
        _work = priorities.copy()
        _work["Executive"] = _work[exec_col].map(lambda v: clean_text(v) or "Unspecified")
        executive_summary = _work.groupby("Executive", dropna=False).agg(
            **{"Pending Tickets": ("Ticket No", "count"),
               "Aged 7+ Days": ("Days Old", lambda s: int((pd.to_numeric(s, errors="coerce").fillna(0) >= 7).sum())),
               "Escalated Tickets": ("Has Escalation", lambda s: int(s.astype(bool).sum())),
               "Repeat-call Flags": ("Is Repeat Call", lambda s: int(s.astype(bool).sum())),
               "Overdue Scheduled": ("Scheduled Overdue", lambda s: int(s.astype(bool).sum())),
               "Average Age (days)": ("Days Old", lambda s: round(pd.to_numeric(s, errors="coerce").fillna(0).mean(), 1)),
            }
        ).reset_index().sort_values(["Pending Tickets", "Escalated Tickets"], ascending=False).reset_index(drop=True)
    else:
        executive_summary = pd.DataFrame(columns=["Executive", "Pending Tickets", "Aged 7+ Days", "Escalated Tickets", "Repeat-call Flags", "Overdue Scheduled", "Average Age (days)"])
    age_summary = pd.cut(priorities["Days Old"], bins=[-1, 0, 2, 6, 13, 29, float("inf")], labels=["0 days", "1–2 days", "3–6 days", "7–13 days", "14–29 days", "30+ days"]).value_counts(sort=False).rename_axis("Age Bucket").reset_index(name="Unique Tickets")
    escalated = int(priorities["Has Escalation"].astype(bool).sum())
    repeat_calls = int(priorities["Is Repeat Call"].astype(bool).sum())
    overdue_scheduled = int(priorities["Scheduled Overdue"].sum())
    older_7 = int((priorities["Days Old"] >= 7).sum())

    # Use closed timestamps only where the uploaded Calls Registered report actually contains them.
    closed_count = None
    closed_time_col = find_col(registered_for_day, ["CLOSED TIME", "Closed Time"]) if not registered_for_day.empty else None
    if registered_count is not None and closed_time_col:
        closed_ts = pd.to_datetime(registered_for_day[closed_time_col], errors="coerce", format="mixed")
        closed_ts = closed_ts.where(closed_ts.dt.year > 1900)
        closed_count = int((closed_ts.dt.date == analysis_date).sum())

    # Data-quality indicators use the final active queue, while ticketless source rows remain flagged.
    missing_exec_count = int(priorities["Missing Executive"].sum()) if "Missing Executive" in priorities else 0
    missing_tech_count = int(priorities["Missing Technician"].sum()) if "Missing Technician" in priorities else 0
    missing_schedule_count = int(priorities["Scheduled Date"].map(lambda v: not bool(clean_text(v))).sum()) if "Scheduled Date" in priorities else len(priorities)
    current_raw_ticket_col = get_ticket_col(current_type_rows)
    missing_ticket_count = int(current_type_rows[current_raw_ticket_col].map(lambda v: not bool(clean_text(v))).sum()) if current_raw_ticket_col else len(current_type_rows)
    source_row_duplicates = max(0, len(current_eligible_rows) - len(priorities))
    excluded_pending_rows = int(excluded_pending_call_type_mask(current["df"]).sum())
    excluded_pending_tickets = distinct_ticket_count(current["df"].loc[excluded_pending_call_type_mask(current["df"])])
    data_quality_metrics = {
        "missing_executive": missing_exec_count,
        "missing_technician": missing_tech_count,
        "missing_schedule": missing_schedule_count,
        "missing_ticket_number": missing_ticket_count,
        "rows_beyond_distinct_tickets": source_row_duplicates,
        "soft_closed_tickets_excluded": current_exclusion_stats["soft_closed_tickets"],
        "negative_response_tickets_excluded": current_exclusion_stats["negative_response_tickets"],
        "current_source_distinct_tickets": current_exclusion_stats["source_distinct_tickets"],
    }

    # Data-quality / provenance notes. Eligible counts mean active tickets after queue reconciliation.
    dq_rows = []
    for r in reports:
        if r["report_type"] == "pending_calls":
            source_df = r["df"]
            unique = count_distinct(source_df)
            active_grouped, active_rows, report_exclusions = active_pending_data(r, reports)
            all_ids = _group_ticket_ids(summarize_pending_rows(filter_pending_call_types(source_df)))
            active_ids = report_exclusions["active_ticket_ids"]
            dq_rows.append({
                "File": r["filename"], "Report Type": r["report_type"], "Source Rows": len(source_df),
                "Distinct Tickets": unique, "Eligible Rows": len(active_rows),
                "Eligible Tickets": len(active_grouped),
                "Excluded Rows": max(0, len(source_df) - len(active_rows)),
                "Excluded Tickets": len(all_ids - active_ids),
                "Rows beyond distinct tickets": max(0, len(active_rows) - len(active_grouped)),
                "Period": r["metadata"], "Snapshot Used For": r["snapshot_dt"].strftime("%Y-%m-%d %H:%M"),
                "Timestamp Basis": r["snapshot_source"],
                "Note": (f"Active queue excludes {report_exclusions['soft_closed_tickets']} ticket(s) soft-closed by this snapshot and "
                         f"{report_exclusions['negative_response_tickets']} ticket(s) marked Negative Response from Customer; "
                         "Courtesy/Courtesy Visit and Dealer Defective call types are also excluded."),
            })
        elif r["report_type"] == "soft_closure":
            dq_rows.append({
                "File": r["filename"], "Report Type": r["report_type"], "Source Rows": len(r["df"]),
                "Distinct Tickets": count_distinct(r["df"]), "Eligible Rows": len(r["df"]),
                "Eligible Tickets": count_distinct(r["df"]), "Excluded Rows": 0, "Excluded Tickets": 0,
                "Rows beyond distinct tickets": max(0, len(r["df"]) - count_distinct(r["df"])),
                "Period": r["metadata"], "Snapshot Used For": r["snapshot_dt"].strftime("%Y-%m-%d %H:%M"),
                "Timestamp Basis": r["snapshot_source"], "Note": "Used to remove tickets with soft-closure event timestamps at or before each Pending Call snapshot.",
            })
        else:
            dq_rows.append({
                "File": r["filename"], "Report Type": r["report_type"], "Source Rows": len(r["df"]),
                "Distinct Tickets": count_distinct(r["df"]), "Eligible Rows": len(r["df"]),
                "Eligible Tickets": count_distinct(r["df"]), "Excluded Rows": 0, "Excluded Tickets": 0,
                "Rows beyond distinct tickets": max(0, len(r["df"]) - count_distinct(r["df"])),
                "Period": r["metadata"], "Snapshot Used For": r["snapshot_dt"].strftime("%Y-%m-%d %H:%M"),
                "Timestamp Basis": r["snapshot_source"], "Note": "Source report classified from its column headers.",
            })
    dq_rows += [
        {"File": "Analysis rule", "Report Type": "Age-only ordering", "Source Rows": "", "Distinct Tickets": "", "Eligible Rows": "", "Eligible Tickets": "", "Excluded Rows": "", "Excluded Tickets": "", "Rows beyond distinct tickets": "", "Period": "Days Old descending; oldest first", "Snapshot Used For": "", "Timestamp Basis": "Days Old column; Call Book Date used only if Days Old is blank", "Note": "The only call-ordering key is age. Equal-age tickets retain source order."},
        {"File": "Analysis rule", "Report Type": "Active pending queue", "Source Rows": "", "Distinct Tickets": "", "Eligible Rows": "", "Eligible Tickets": "", "Excluded Rows": "", "Excluded Tickets": "", "Rows beyond distinct tickets": "", "Period": "Active calls only", "Snapshot Used For": "", "Timestamp Basis": "Soft Closure Date / ClosedDate compared with Pending Call snapshot time", "Note": "Exclude Courtesy and Dealer Defective types, tickets soft-closed by snapshot time, and tickets marked Negative Response from Customer."},
        {"File": "Analysis rule", "Report Type": "Snapshot comparison", "Source Rows": "", "Distinct Tickets": "", "Eligible Rows": "", "Eligible Tickets": "", "Excluded Rows": "", "Excluded Tickets": "", "Rows beyond distinct tickets": "", "Period": "New / continuing / no longer present / status changed / age increased", "Snapshot Used For": "", "Timestamp Basis": "Ticket-number matching on the active queue for each snapshot", "Note": "A ticket absent from a later Pending Call export is not automatically labelled closed."},
    ]

    return {
        "analysis_date": analysis_date,
        "reports": reports,
        "pending_reports": pending_reports,
        "current_pending_report": current,
        "previous_pending_report": previous,
        "current_pending_rows": len(current_eligible_rows),
        "current_unique_tickets": len(priorities),
        "current_source_distinct_tickets": current_exclusion_stats["source_distinct_tickets"],
        "soft_closed_tickets_excluded": current_exclusion_stats["soft_closed_tickets"],
        "negative_response_tickets_excluded": current_exclusion_stats["negative_response_tickets"],
        "prior_unique_tickets": len(active_pending_data(previous, reports)[0]) if previous else None,
        "excluded_pending_rows": excluded_pending_rows,
        "excluded_pending_tickets": excluded_pending_tickets,
        "priorities": priorities,
        "top20": top20,
        "top20_executive_summary": top20_executive_summary,
        "comparison": comparisons,
        "movement_counts": movement_counts,
        "csat_report": csat_report,
        "csat": csat,
        "csat_summary": csat_summary,
        "csat_metrics": csat_metrics,
        "csat_previous_report": csat_previous_report,
        "csat_comparison": csat_comparison,
        "csat_movement": csat_movement,
        "registered_report": reg_report,
        "registered": registered,
        "registered_for_day": registered_for_day,
        "registered_count": registered_count,
        "registered_date_coverage": registered_date_coverage,
        "closed_count": closed_count,
        "status_summary": status_summary,
        "call_type_summary": call_type_summary,
        "franchise_summary": franchise_summary,
        "executive_summary": executive_summary,
        "age_summary": age_summary,
        "escalated": escalated,
        "repeat_calls": repeat_calls,
        "overdue_scheduled": overdue_scheduled,
        "older_7": older_7,
        "data_quality_metrics": data_quality_metrics,
        "data_quality": pd.DataFrame(dq_rows),
    }


def _filter_to_scope(df: pd.DataFrame, scope_mode: str, selection: str) -> Tuple[pd.DataFrame, bool]:
    """Filter a source frame to a selected franchise or service executive.

    Returns (filtered_frame, key_supported). If the source does not have the matching
    column, returns an empty frame so branch-wide values are never mislabelled as scoped.
    """
    if scope_mode == "branch":
        return df.copy(), True
    aliases = ( ["Franchise Name", "FrName", "Franchise"] if scope_mode == "franchise"
                else ["Service Executive Name", "Branch Exe Name", "Branch Executive Name", "Executive Name"] )
    col = find_col(df, aliases)
    if col is None:
        return df.iloc[0:0].copy(), False
    target = norm(selection)
    return df.loc[df[col].map(norm) == target].copy(), True


def _feedback_outputs(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    feedback_col = find_col(df, ["FeedBack", "Feedback", "Feedback Score"]) if not df.empty else None
    summary = pd.DataFrame(columns=["Feedback", "Count", "Share %"])
    metrics = {"total": 0, "source_rows": len(df), "blank": 0, "happy": 0, "ok": 0,
               "not_happy": 0, "happy_pct": None, "not_happy_pct": None,
               "css_pct": None, "css_pct_rounded": None}
    if feedback_col is None:
        return summary, metrics
    feedback = df[feedback_col].map(lambda v: clean_text(v).upper())
    valid = feedback[feedback != ""]
    total = len(valid)
    counts = valid.value_counts()
    summary = pd.DataFrame([
        {"Feedback": label, "Count": int(count), "Share %": round(100 * int(count) / total, 2) if total else 0}
        for label, count in counts.items()
    ])
    happy = int((valid == "HAPPY").sum())
    ok = int((valid == "OK").sum())
    not_happy = int((valid == "NOT HAPPY").sum())
    css = 100 * (happy - not_happy) / total if total else None
    metrics = {
        "total": total, "source_rows": len(df), "blank": int((feedback == "").sum()),
        "happy": happy, "ok": ok, "not_happy": not_happy,
        "happy_pct": round(100 * happy / total, 2) if total else None,
        "not_happy_pct": round(100 * not_happy / total, 2) if total else None,
        "css_pct": round(css, 2) if css is not None else None,
        "css_pct_rounded": int(round(css)) if css is not None else None,
    }
    return summary, metrics


def _simple_counts(df: pd.DataFrame, source_col_aliases: Sequence[str], output_col: str) -> pd.DataFrame:
    col = find_col(df, source_col_aliases) if not df.empty else None
    if col is None:
        return pd.DataFrame(columns=[output_col, "Unique Tickets"])
    vals = df[col].map(lambda v: clean_text(v) or "Unspecified")
    return vals.value_counts().rename_axis(output_col).reset_index(name="Unique Tickets")


def scope_analysis(analysis: Dict[str, Any], scope_mode: str = "branch", selection: str = "") -> Dict[str, Any]:
    """Return a view-specific analysis while preserving age-only ordering.

    scope_mode is one of branch, franchise, executive. Scoped CSAT and registered-call
    figures are calculated only when those source reports contain a matching scope field.
    """
    mode = (scope_mode or "branch").strip().lower()
    if mode not in {"branch", "franchise", "executive"}:
        mode = "branch"
    if mode != "branch" and not clean_text(selection):
        raise ValueError("Choose a franchise or service executive for this view.")

    scoped = dict(analysis)
    scoped["scope_mode"] = mode
    scoped["scope_selection"] = clean_text(selection)
    scoped["scope_label"] = (
        "Hyderabad Branch" if mode == "branch" else
        f"Franchise: {clean_text(selection)}" if mode == "franchise" else
        f"Service Executive: {clean_text(selection)}"
    )

    all_priorities = analysis["priorities"].copy()
    priorities, _ = _filter_to_scope(all_priorities, mode, selection)
    # Age is the only sort key in every view. Stable sorting keeps source order for ties.
    priorities["Days Old"] = pd.to_numeric(priorities.get("Days Old", pd.Series(index=priorities.index, dtype=float)), errors="coerce").fillna(0).astype(int)
    priorities = priorities.sort_values("Days Old", ascending=False, kind="stable").reset_index(drop=True)
    if "Order" in priorities.columns:
        priorities["Order"] = range(1, len(priorities) + 1)
    scoped["priorities"] = priorities
    scoped["top20"] = priorities.head(20).copy()

    # Calculate descriptive mixes strictly from the scoped queue/Top 20.
    top20 = scoped["top20"].copy()
    exec_col = find_col(top20, ["Service Executive Name"])
    franchise_col = find_col(top20, ["Franchise Name"])
    status_col = find_col(top20, ["Status"])
    if len(top20):
        if exec_col:
            exec_vals = top20[exec_col].map(lambda v: clean_text(v) or "Unspecified")
            counts = exec_vals.value_counts()
            top20["Executive % of Top 20"] = exec_vals.map(counts).astype(float) * 100 / len(top20)
            ex_summary = pd.DataFrame({"Executive": counts.index, "Top 20 Calls": counts.values})
            ex_summary["Share of Top 20 (%)"] = ex_summary["Top 20 Calls"] * 100 / len(top20)
        else:
            top20["Executive % of Top 20"] = 100.0
            ex_summary = pd.DataFrame({"Executive": ["Unspecified"], "Top 20 Calls": [len(top20)], "Share of Top 20 (%)": [100.0]})
        if franchise_col:
            fr_vals = top20[franchise_col].map(lambda v: clean_text(v) or "Unspecified")
            counts_fr = fr_vals.value_counts()
            top20["Franchise % of Top 20"] = fr_vals.map(counts_fr).astype(float) * 100 / len(top20)
            fr_top_summary = pd.DataFrame({"Franchise": counts_fr.index, "Top 20 Calls": counts_fr.values})
            fr_top_summary["Share of Top 20 (%)"] = fr_top_summary["Top 20 Calls"] * 100 / len(top20)
        else:
            top20["Franchise % of Top 20"] = 100.0
            fr_top_summary = pd.DataFrame({"Franchise": ["Unspecified"], "Top 20 Calls": [len(top20)], "Share of Top 20 (%)": [100.0]})
        if status_col:
            st_vals = top20[status_col].map(lambda v: clean_text(v) or "Unspecified")
            counts_st = st_vals.value_counts()
            st_top_summary = pd.DataFrame({"Status": counts_st.index, "Top 20 Calls": counts_st.values})
            st_top_summary["Share of Top 20 (%)"] = st_top_summary["Top 20 Calls"] * 100 / len(top20)
        else:
            st_top_summary = pd.DataFrame(columns=["Status", "Top 20 Calls", "Share of Top 20 (%)"])
        ex_summary = ex_summary.sort_values(["Top 20 Calls", "Executive"], ascending=[False, True], kind="stable").reset_index(drop=True)
        fr_top_summary = fr_top_summary.sort_values(["Top 20 Calls", "Franchise"], ascending=[False, True], kind="stable").reset_index(drop=True)
        st_top_summary = st_top_summary.sort_values("Top 20 Calls", ascending=False, kind="stable").reset_index(drop=True)
        scoped["top20"] = top20
    else:
        scoped["top20_executive_summary"] = pd.DataFrame(columns=["Executive", "Top 20 Calls", "Share of Top 20 (%)"])
        ex_summary = scoped["top20_executive_summary"]
        fr_top_summary = pd.DataFrame(columns=["Franchise", "Top 20 Calls", "Share of Top 20 (%)"])
        st_top_summary = pd.DataFrame(columns=["Status", "Top 20 Calls", "Share of Top 20 (%)"])
    scoped["top20_executive_summary"] = ex_summary
    scoped["top20_franchise_summary"] = fr_top_summary
    scoped["top20_status_summary"] = st_top_summary

    # Reconcile source-row counts and exclusions for the current selection.
    current = analysis["current_pending_report"]
    all_reports = analysis.get("reports", [])
    active_grouped, active_rows, active_stats = active_pending_data(current, all_reports)
    active_rows_scoped, _ = _filter_to_scope(active_rows, mode, selection)
    scoped["current_pending_rows"] = len(active_rows_scoped)
    scoped["current_unique_tickets"] = len(priorities)

    filtered_source = filter_pending_call_types(current.get("df", pd.DataFrame()))
    filtered_source_scoped, scope_col_supported = _filter_to_scope(filtered_source, mode, selection)
    ticket_col = get_ticket_col(filtered_source_scoped)
    source_ids = {clean_text(v) for v in filtered_source_scoped[ticket_col].tolist() if clean_text(v)} if ticket_col else set()
    scoped["current_source_distinct_tickets"] = len(source_ids)
    active_ids = set(priorities["Ticket No"].map(clean_text)) if "Ticket No" in priorities.columns else set()
    soft_ids = set(active_stats.get("soft_closed_ids", set())) & source_ids
    negative_ids = set(active_stats.get("negative_response_ids", set())) & source_ids
    scoped["soft_closed_tickets_excluded"] = len(soft_ids)
    scoped["negative_response_tickets_excluded"] = len(negative_ids - soft_ids)
    scoped["prior_unique_tickets"] = None

    # Scope comparison movement: count new/continuing from the current scope and missing from the previous scope.
    comp = analysis.get("comparison", pd.DataFrame()).copy()
    if mode != "branch" and not comp.empty:
        if mode == "franchise":
            prev_key, cur_key = "Previous Franchise", "Current Franchise"
        else:
            prev_key, cur_key = "Previous Executive", "Current Executive"
        if prev_key in comp.columns and cur_key in comp.columns:
            prev_match = comp[prev_key].map(norm) == norm(selection)
            cur_match = comp[cur_key].map(norm) == norm(selection)
            movement_col = find_col(comp, ["Movement"])
            movement_text = comp[movement_col].map(clean_text) if movement_col else pd.Series("", index=comp.index)
            new_mask = movement_text.str.startswith("Newly present") & cur_match
            missing_mask = movement_text.str.startswith("No longer present") & prev_match
            common_scope = prev_match & cur_match
            continuing_mask = common_scope & movement_text.str.startswith(("Present",))
            changed_mask = common_scope & movement_text.str.contains("status changed", case=False)
            age_mask = common_scope & movement_text.str.contains("age increased", case=False)
            scoped["movement_counts"] = {"new": int(new_mask.sum()), "continuing": int(continuing_mask.sum()),
                                         "missing": int(missing_mask.sum()), "status_changed": int(changed_mask.sum()),
                                         "age_increased": int(age_mask.sum())}
            scoped["comparison"] = comp.loc[new_mask | missing_mask | common_scope].copy().reset_index(drop=True)
        else:
            scoped["movement_counts"] = {"new": 0, "continuing": 0, "missing": 0, "status_changed": 0, "age_increased": 0}
            scoped["comparison"] = pd.DataFrame()
    else:
        scoped["movement_counts"] = analysis["movement_counts"]
        scoped["comparison"] = comp

    # Scoped status, call type, age-band and franchise/executive/technician summaries.
    scoped["status_summary"] = _simple_counts(priorities, ["Status"], "Status")
    scoped["call_type_summary"] = _simple_counts(priorities, ["Call Type"], "Call Type")
    scoped["age_summary"] = pd.cut(
        priorities["Days Old"], bins=[-1, 0, 2, 6, 13, 29, float("inf")],
        labels=["0 days", "1–2 days", "3–6 days", "7–13 days", "14–29 days", "30+ days"],
    ).value_counts(sort=False).rename_axis("Age Bucket").reset_index(name="Unique Tickets")
    scoped["older_7"] = int((priorities["Days Old"] >= 7).sum())
    scoped["escalated"] = int(priorities.get("Has Escalation", pd.Series(False, index=priorities.index)).astype(bool).sum())
    scoped["repeat_calls"] = int(priorities.get("Is Repeat Call", pd.Series(False, index=priorities.index)).astype(bool).sum())
    scoped["overdue_scheduled"] = int(priorities.get("Scheduled Overdue", pd.Series(False, index=priorities.index)).astype(bool).sum())

    franchise_col_all = find_col(priorities, ["Franchise Name"])
    if franchise_col_all:
        temp = priorities.copy()
        temp["Franchise"] = temp[franchise_col_all].map(lambda v: clean_text(v) or "Unspecified")
        scoped["franchise_summary"] = temp.groupby("Franchise", dropna=False).agg(
            **{"Pending Tickets": ("Ticket No", "count"),
               "Aged >2 Days": ("Days Old", lambda x: int((pd.to_numeric(x, errors="coerce").fillna(0) > 2).sum())),
               "Aged 7+ Days": ("Days Old", lambda x: int((pd.to_numeric(x, errors="coerce").fillna(0) >= 7).sum())),
               "Escalated Tickets": ("Has Escalation", lambda x: int(x.astype(bool).sum())),
               "Repeat-call Flags": ("Is Repeat Call", lambda x: int(x.astype(bool).sum())),
               "Average Age (days)": ("Days Old", lambda x: round(pd.to_numeric(x, errors="coerce").fillna(0).mean(), 1)),
            }
        ).reset_index().sort_values(["Aged >2 Days", "Pending Tickets"], ascending=False, kind="stable").reset_index(drop=True)
    else:
        scoped["franchise_summary"] = pd.DataFrame(columns=["Franchise", "Pending Tickets", "Aged >2 Days", "Aged 7+ Days", "Escalated Tickets", "Repeat-call Flags", "Average Age (days)"])

    ex_col_all = find_col(priorities, ["Service Executive Name"])
    if ex_col_all:
        temp = priorities.copy()
        temp["Executive"] = temp[ex_col_all].map(lambda v: clean_text(v) or "Unspecified")
        scoped["executive_summary"] = temp.groupby("Executive", dropna=False).agg(
            **{"Pending Tickets": ("Ticket No", "count"), "Aged 7+ Days": ("Days Old", lambda x: int((x >= 7).sum())),
               "Escalated Tickets": ("Has Escalation", lambda x: int(x.astype(bool).sum())),
               "Repeat-call Flags": ("Is Repeat Call", lambda x: int(x.astype(bool).sum())),
               "Overdue Scheduled": ("Scheduled Overdue", lambda x: int(x.astype(bool).sum())),
               "Average Age (days)": ("Days Old", lambda x: round(float(x.mean()), 1))}
        ).reset_index().sort_values("Pending Tickets", ascending=False, kind="stable").reset_index(drop=True)
    else:
        scoped["executive_summary"] = pd.DataFrame(columns=["Executive", "Pending Tickets", "Aged 7+ Days", "Escalated Tickets", "Repeat-call Flags", "Overdue Scheduled", "Average Age (days)"])

    tech_col = find_col(priorities, ["Technician Name"])
    if tech_col:
        tech = priorities.copy()
        tech["Technician"] = tech[tech_col].map(lambda v: clean_text(v) or "Unspecified")
        scoped["technician_summary"] = tech.groupby("Technician", dropna=False).agg(
            **{"Pending Tickets": ("Ticket No", "count"), "Aged >2 Days": ("Days Old", lambda x: int((x > 2).sum())),
               "Aged 7+ Days": ("Days Old", lambda x: int((x >= 7).sum()))}
        ).reset_index().sort_values(["Pending Tickets", "Aged 7+ Days"], ascending=False, kind="stable").reset_index(drop=True)
    else:
        scoped["technician_summary"] = pd.DataFrame(columns=["Technician", "Pending Tickets", "Aged >2 Days", "Aged 7+ Days"])

    # Exclusion call types within the selected scope.
    source_all = current.get("df", pd.DataFrame())
    ex_mask = excluded_pending_call_type_mask(source_all)
    excluded_by_type = source_all.loc[ex_mask].copy()
    excluded_by_type_scoped, _ = _filter_to_scope(excluded_by_type, mode, selection)
    scoped["excluded_pending_rows"] = len(excluded_by_type_scoped)
    scoped["excluded_pending_tickets"] = distinct_ticket_count(excluded_by_type_scoped)
    missing_ticket_col = get_ticket_col(filtered_source_scoped)
    missing_ticket_count = int(filtered_source_scoped[missing_ticket_col].map(lambda x: not bool(clean_text(x))).sum()) if missing_ticket_col else len(filtered_source_scoped)
    missing_schedule = int(priorities["Scheduled Date"].map(lambda x: not bool(clean_text(x)) or (parse_dt(x) is None)).sum()) if "Scheduled Date" in priorities else len(priorities)
    scoped["data_quality_metrics"] = {
        "missing_executive": int(priorities.get("Missing Executive", pd.Series(False, index=priorities.index)).astype(bool).sum()),
        "missing_technician": int(priorities.get("Missing Technician", pd.Series(False, index=priorities.index)).astype(bool).sum()),
        "missing_schedule": missing_schedule,
        "missing_ticket_number": missing_ticket_count,
        "rows_beyond_distinct_tickets": max(0, len(active_rows_scoped) - len(priorities)),
        "soft_closed_tickets_excluded": len(soft_ids),
        "negative_response_tickets_excluded": len(negative_ids - soft_ids),
        "current_source_distinct_tickets": len(source_ids),
    }

    # Scope the satisfaction and registered-call datasets only when their own report has the required field.
    csat_report = analysis.get("csat_report")
    csat_source = csat_report.get("df", pd.DataFrame()) if csat_report else pd.DataFrame()
    csat_filtered, csat_key_supported = _filter_to_scope(csat_source, mode, selection)
    if mode != "branch" and not csat_key_supported:
        csat_filtered = csat_source.iloc[0:0].copy()
    scoped["csat"] = csat_filtered
    scoped["csat_summary"], scoped["csat_metrics"] = _feedback_outputs(csat_filtered)
    scoped["csat_scope_supported"] = csat_key_supported
    previous_csat_report = analysis.get("csat_previous_report")
    previous_csat_df = previous_csat_report.get("df", pd.DataFrame()) if previous_csat_report else pd.DataFrame()
    previous_csat_filtered, prev_csat_supported = _filter_to_scope(previous_csat_df, mode, selection)
    prev_sum, prev_metrics = _feedback_outputs(previous_csat_filtered)
    css_delta = None
    if prev_metrics.get("css_pct") is not None and scoped["csat_metrics"].get("css_pct") is not None:
        css_delta = round(scoped["csat_metrics"]["css_pct"] - prev_metrics["css_pct"], 2)
    scoped["csat_movement"] = dict(analysis.get("csat_movement", {}))
    scoped["csat_movement"]["css_delta_pp"] = css_delta
    scoped["csat_movement"]["previous_rows"] = prev_metrics.get("total") if previous_csat_report else None
    scoped["csat_movement"]["current_rows"] = scoped["csat_metrics"].get("total", 0)

    # Scope Calls Registered figures too, when a matching column is available.
    reg = analysis.get("registered", pd.DataFrame()).copy()
    reg_day = analysis.get("registered_for_day", pd.DataFrame()).copy()
    reg_scoped, reg_supported = _filter_to_scope(reg, mode, selection)
    reg_day_scoped, reg_day_supported = _filter_to_scope(reg_day, mode, selection)
    if mode != "branch" and (not reg_supported or not reg_day_supported):
        scoped["registered_count"] = None
        scoped["registered_for_day"] = reg_day.iloc[0:0].copy()
    else:
        scoped["registered_for_day"] = reg_day_scoped
        col_reg = get_ticket_col(reg_day_scoped)
        scoped["registered_count"] = len({clean_text(x) for x in reg_day_scoped[col_reg] if clean_text(x)}) if col_reg and analysis.get("registered_count") is not None else analysis.get("registered_count")
    scoped["registered"] = reg_scoped

    # Add scope metadata for reporting and group-update snapshots.
    scoped["scope_summary"] = {
        "mode": mode,
        "selection": clean_text(selection),
        "active_tickets": len(priorities),
        "aged_over_2": int((priorities["Days Old"] > 2).sum()),
        "aged_7_plus": int((priorities["Days Old"] >= 7).sum()),
        "oldest_days": int(priorities["Days Old"].max()) if not priorities.empty else None,
        "status_counts": scoped["status_summary"].to_dict("records"),
        "csat_scoped": bool(csat_key_supported or mode == "branch"),
    }
    return scoped


def _date_label(value: Any) -> str:
    try:
        return pd.Timestamp(value).strftime("%d %b %Y")
    except Exception:
        return clean_text(value)


def _snapshot_status(analysis: Dict[str, Any]) -> str:
    snap = analysis["current_pending_report"]["snapshot_dt"]
    # Conservative label: a late snapshot can be called an EOD snapshot, but never assume it is complete.
    if snap.date() == analysis["analysis_date"] and snap.hour >= 18:
        return "LATE-DAY SNAPSHOT · confirm all source reports are final"
    return "INTRADAY SNAPSHOT · not a confirmed end-of-day closeout"


def make_priority_png(analysis: Dict[str, Any]) -> bytes:
    """Render the 20 oldest tickets with a scope-appropriate descriptive chart."""
    import matplotlib.pyplot as plt
    import numpy as np
    import textwrap

    mode = analysis.get("scope_mode", "branch")
    selection = clean_text(analysis.get("scope_selection", ""))
    data = analysis["top20"].copy().head(20)
    snap = analysis["current_pending_report"]["snapshot_dt"]
    fig = plt.figure(figsize=(21, 11.2), dpi=160, facecolor="#FFFFFF")

    if mode == "franchise":
        title = f"Pending calls — {selection}: 20 oldest tickets"
        context = f"Franchise view: {selection}"
    elif mode == "executive":
        title = f"Pending calls — {selection}: 20 oldest tickets"
        context = f"Executive view: all franchises assigned to {selection}"
    else:
        title = "Pending calls — 20 oldest tickets"
        context = "Hyderabad Service Branch"
    fig.text(0.018, 0.962, title, fontsize=20, color="#303236", va="top")
    fig.text(0.018, 0.925,
             f"{context}  |  As of {snap.strftime('%d %b %Y, %I:%M %p')}  |  Ordered by call age, oldest first",
             fontsize=10, color="#5B6570", va="top")
    fig.text(0.982, 0.962, f"{analysis['current_unique_tickets']:,} ACTIVE PENDING TICKETS",
             fontsize=11, weight="bold", ha="right", va="top", color="#303030")

    ax = fig.add_axes([0.012, 0.305, 0.976, 0.555])
    ax.axis("off")
    col_def = [
        ("Order", "No.", 0.035),
        ("Ticket No", "Ticket No.", 0.085),
        ("Days Old", "Days Old", 0.055),
        ("Customer Name", "Customer", 0.125),
        ("Franchise Name", "Franchise", 0.130),
        ("Service Executive Name", "Service Executive", 0.130),
        ("Technician Name", "Technician", 0.110),
        ("Call Type", "Call Type", 0.105),
        ("Status", "Status", 0.100),
    ]
    if mode == "branch":
        col_def.append(("Executive % of Top 20", "Exec. % of Top 20", 0.080))
    elif mode == "executive":
        col_def.append(("Franchise % of Top 20", "Franchise % of Top 20", 0.080))
    present = [(src, label, width) for src, label, width in col_def if src in data.columns]
    total = sum(c[2] for c in present) or 1
    col_widths = [c[2] / total for c in present]

    rows = []
    for _, row in data.iterrows():
        vals = []
        for src, _, _ in present:
            value = clean_text(row.get(src, ""))
            if src in {"Executive % of Top 20", "Franchise % of Top 20"} and value:
                try:
                    value = f"{float(value):.1f}%"
                except (TypeError, ValueError):
                    pass
            limit = {
                "Franchise Name": 30, "Customer Name": 26,
                "Service Executive Name": 27, "Technician Name": 23,
                "Call Type": 20, "Status": 20,
            }.get(src)
            if limit and len(value) > limit:
                value = value[:limit - 3] + "..."
            vals.append(value)
        rows.append(vals)

    table = ax.table(
        cellText=rows,
        colLabels=[label for _, label, _ in present],
        cellLoc="left", colLoc="center", loc="center",
        colWidths=col_widths, bbox=[0.0, 0.0, 1.0, 1.0],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8.2)
    centered = {"Order", "Days Old", "Executive % of Top 20", "Franchise % of Top 20"}
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#D0D4D8")
        cell.set_linewidth(0.55)
        if r == 0:
            cell.set_facecolor("#EEEEEE")
            cell.get_text().set_color("#202326")
            cell.get_text().set_weight("bold")
            cell.get_text().set_fontsize(8.1)
            cell.set_height(0.045)
            cell.get_text().set_ha("center")
        else:
            cell.set_facecolor("#FFFFFF")
            cell.get_text().set_color("#202326")
            cell.set_height(0.034)
            if present[c][0] in centered:
                cell.get_text().set_ha("center")
            if present[c][0] == "Order":
                cell.get_text().set_weight("bold")

    # The lower chart changes by view; it is descriptive only and never affects ordering.
    if mode == "franchise":
        chart = analysis.get("top20_status_summary", pd.DataFrame()).copy()
        category_col = "Status"
        chart_title = "Top 20 calls by status — franchise update"
    elif mode == "executive":
        chart = analysis.get("top20_franchise_summary", pd.DataFrame()).copy()
        category_col = "Franchise"
        if len(chart) <= 1:
            chart = analysis.get("top20_status_summary", pd.DataFrame()).copy()
            category_col = "Status"
            chart_title = "Top 20 calls by status — executive update"
        else:
            chart_title = "Top 20 calls across your franchises"
    else:
        chart = analysis.get("top20_executive_summary", pd.DataFrame()).copy()
        category_col = "Executive"
        chart_title = "Top 20 calls by service executive"

    if not chart.empty and category_col in chart.columns and "Top 20 Calls" in chart.columns:
        chart["Top 20 Calls"] = pd.to_numeric(chart["Top 20 Calls"], errors="coerce").fillna(0)
        chart["Share of Top 20 (%)"] = pd.to_numeric(chart.get("Share of Top 20 (%)", 0), errors="coerce").fillna(0)
        chart[category_col] = chart[category_col].map(lambda v: clean_text(v) or "Unspecified")
        chart = chart.sort_values("Top 20 Calls", ascending=False, kind="stable").copy()
        if len(chart) > 6:
            main = chart.head(5).copy()
            rest = chart.iloc[5:]
            main = pd.concat([main, pd.DataFrame([{
                category_col: "Other", "Top 20 Calls": int(rest["Top 20 Calls"].sum()),
                "Share of Top 20 (%)": float(rest["Share of Top 20 (%)"].sum()),
            }])], ignore_index=True)
            chart = main
        labels = [textwrap.fill(v, width=29, break_long_words=False) for v in chart[category_col].astype(str)]
        y = np.arange(len(chart))
        counts = chart["Top 20 Calls"].to_numpy(dtype=float)
        shares = chart["Share of Top 20 (%)"].to_numpy(dtype=float)
        chart_ax = fig.add_axes([0.19, 0.075, 0.735, 0.155])
        chart_ax.barh(y, counts, color="#3A78A5", height=0.58)
        chart_ax.set_yticks(y)
        chart_ax.set_yticklabels(labels, fontsize=7.8, color="#263746")
        chart_ax.invert_yaxis()
        chart_ax.set_title(chart_title, loc="left", fontsize=10.5, color="#18344D", fontweight="bold", pad=5)
        chart_ax.tick_params(axis="x", labelsize=7.5, colors="#435365", length=0, pad=3)
        chart_ax.tick_params(axis="y", length=0, pad=7)
        chart_ax.xaxis.grid(True, color="#E3E8ED", linewidth=0.65)
        chart_ax.set_axisbelow(True)
        for spine in chart_ax.spines.values():
            spine.set_visible(False)
        xmax = max(float(counts.max()), 1.0)
        chart_ax.set_xlim(0, xmax * 1.42)
        chart_ax.set_xlabel("Number of calls in Top 20", fontsize=7.5, color="#435365", labelpad=2)
        for yy, count, share in zip(y, counts, shares):
            chart_ax.text(count + xmax * 0.025, yy, f"{int(count)} calls  ·  {share:.1f}%",
                          va="center", ha="left", fontsize=7.6, color="#263746", weight="bold")
    else:
        fig.text(0.018, 0.15, "No chartable calls in this view.", fontsize=9, color="#435365")

    note = "Sorted only by Days Old, highest to lowest. No weighted score or escalation-based ranking is used."
    fig.text(0.018, 0.025, note, fontsize=8.7, color="#4F5963", va="bottom")
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    return buf.getvalue()


def make_management_png(analysis: Dict[str, Any]) -> bytes:
    """Create a high-contrast management image whose charts adapt to the selected view."""
    import matplotlib.pyplot as plt
    import numpy as np
    import textwrap

    navy = "#18344D"
    teal = "#0B7E83"
    amber = "#C78318"
    red = "#B9363E"
    green = "#237A55"
    ink = "#263746"
    muted = "#435365"
    grid = "#E3E8ED"
    page = "#F3F6F8"
    mode = analysis.get("scope_mode", "branch")
    selection = clean_text(analysis.get("scope_selection", ""))

    fig = plt.figure(figsize=(16, 11), dpi=180, facecolor=page)
    if mode == "franchise":
        heading = "SERVICE OPERATIONS | FRANCHISE DAILY UPDATE"
        scope_subtitle = f"Franchise: {selection}"
    elif mode == "executive":
        heading = "SERVICE OPERATIONS | EXECUTIVE DAILY BRIEF"
        scope_subtitle = f"Service Executive: {selection} · All assigned franchise queues"
    else:
        heading = "SERVICE OPERATIONS | DAILY MANAGEMENT BRIEF"
        scope_subtitle = "Hyderabad Branch"
    fig.text(0.04, 0.962, heading, fontsize=19, weight="bold", color=navy, va="top")
    fig.text(0.04, 0.923,
             f"{scope_subtitle}  ·  Report date {_date_label(analysis['analysis_date'])}  ·  {_snapshot_status(analysis)}",
             fontsize=9.8, color=muted, va="top")
    snap = analysis["current_pending_report"]["snapshot_dt"]
    fig.text(0.96, 0.962, f"AS OF {snap.strftime('%d %b %Y  %I:%M %p')}",
             fontsize=9.3, weight="bold", color=teal, ha="right", va="top")

    current = analysis["current_unique_tickets"]
    mc = analysis["movement_counts"]
    css_rounded = analysis["csat_metrics"].get("css_pct_rounded")
    kpis = [
        ("PENDING TICKETS", f"{current:,}", navy),
        ("AGED 7+ DAYS", f"{analysis['older_7']:,}", amber),
        ("ESCALATED", f"{analysis['escalated']:,}", red),
        ("REPEAT FLAGS", f"{analysis['repeat_calls']:,}", teal),
        ("NEW IN LATEST SNAPSHOT", f"{mc['new']:,}" if analysis["previous_pending_report"] else "—", "#2E6D9C"),
        ("CSS", f"{css_rounded}%" if css_rounded is not None else "—", green),
    ]
    x0, step, card_w = 0.04, 0.155, 0.143
    for i, (label, value, value_color) in enumerate(kpis):
        x = x0 + i * step
        fig.patches.append(plt.Rectangle((x, 0.817), card_w, 0.078, transform=fig.transFigure,
                                         facecolor="#FFFFFF", edgecolor="#D8E0E7", linewidth=1.0, zorder=0))
        fig.text(x + 0.010, 0.868, label, fontsize=7.1, color=muted, weight="bold", va="center")
        fig.text(x + 0.010, 0.835, value, fontsize=17, color=value_color, weight="bold", va="center")

    def style_axis(ax, title, title_size=11.2):
        ax.set_facecolor("#FFFFFF")
        ax.set_title(title, loc="left", color=navy, fontsize=title_size, fontweight="bold", pad=9)
        ax.tick_params(axis="both", labelsize=8.0, colors=ink, length=0, pad=4)
        ax.grid(axis="x", color=grid, linewidth=0.7)
        ax.set_axisbelow(True)
        for spine in ax.spines.values():
            spine.set_visible(False)

    def draw_hbar(ax, frame, label_col, value_col, title, share_col=None, max_rows=5):
        df = frame.copy() if frame is not None else pd.DataFrame()
        if df.empty or label_col not in df.columns or value_col not in df.columns:
            ax.axis("off")
            ax.text(0.03, 0.5, "No matching data available for this view.", color=muted,
                    fontsize=9, transform=ax.transAxes, va="center")
            ax.set_title(title, loc="left", color=navy, fontsize=11.2, fontweight="bold", pad=9)
            return
        df[value_col] = pd.to_numeric(df[value_col], errors="coerce").fillna(0)
        df = df.sort_values(value_col, ascending=False, kind="stable").head(max_rows).copy()
        df[label_col] = df[label_col].map(lambda x: clean_text(x) or "Unspecified")
        labels = [textwrap.fill(v, width=24, break_long_words=False) for v in df[label_col].astype(str)]
        vals = df[value_col].to_numpy(dtype=float)
        y = np.arange(len(df))
        ax.barh(y, vals, color="#3A78A5", height=0.58)
        ax.set_yticks(y)
        ax.set_yticklabels(labels, fontsize=7.6, color=ink)
        ax.invert_yaxis()
        style_axis(ax, title)
        ax.tick_params(axis="y", labelsize=7.6, colors=ink, pad=4)
        xmax = max(float(vals.max()), 1)
        ax.set_xlim(0, xmax * 1.38)
        if share_col and share_col in df.columns:
            shares = pd.to_numeric(df[share_col], errors="coerce").fillna(0).to_numpy(dtype=float)
        else:
            total = float(pd.to_numeric(frame[value_col], errors="coerce").fillna(0).sum()) or 1.0
            shares = vals * 100.0 / total
        for yy, val, share in zip(y, vals, shares):
            ax.text(val + xmax * 0.025, yy, f"{int(val):,}  ·  {share:.1f}%", va="center", ha="left",
                    fontsize=7.4, color=ink, weight="bold")

    # Top-left: ageing always reflects the queue represented by the current view.
    ax_age = fig.add_axes([0.075, 0.545, 0.37, 0.205])
    age = analysis["age_summary"].copy()
    if not age.empty:
        age["Unique Tickets"] = pd.to_numeric(age["Unique Tickets"], errors="coerce").fillna(0)
        age_colors = ["#A8BAC8", "#8AA9BC", "#648EA8", "#2E8588", "#D39A35", "#B94842"]
        ax_age.barh(age["Age Bucket"].astype(str), age["Unique Tickets"], color=age_colors[:len(age)], height=0.62)
        ax_age.invert_yaxis()
        style_axis(ax_age, "Pending backlog by age")
        ax_age.tick_params(axis="y", labelsize=8.4, colors=ink)
        xmax = max(float(age["Unique Tickets"].max()), 1)
        ax_age.set_xlim(0, xmax * 1.14)
        for y, val in enumerate(age["Unique Tickets"].to_numpy()):
            ax_age.text(val + xmax * 0.015, y, f"{int(val):,}", va="center", ha="left", fontsize=8.1, color=ink, weight="bold")
        ax_age.grid(axis="y", visible=False)
    else:
        ax_age.axis("off")
        ax_age.text(0.03, 0.5, "No calls in this view.", color=muted, fontsize=10, transform=ax_age.transAxes, va="center")

    # Top-right chart adapts to the view: branch=executives, franchise=statuses, executive=franchises.
    ax_main = fig.add_axes([0.575, 0.545, 0.35, 0.205])
    if mode == "franchise":
        status_frame = analysis["status_summary"].copy()
        draw_hbar(ax_main, status_frame, "Status", "Unique Tickets", "Franchise status update")
    elif mode == "executive":
        fr_frame = analysis["franchise_summary"].copy()
        if len(fr_frame) > 1:
            draw_hbar(ax_main, fr_frame, "Franchise", "Pending Tickets", "Your pending workload by franchise")
        else:
            status_frame = analysis["status_summary"].copy()
            draw_hbar(ax_main, status_frame, "Status", "Unique Tickets", "Your call status mix")
    else:
        ex_frame = analysis.get("top20_executive_summary", pd.DataFrame()).copy()
        draw_hbar(ax_main, ex_frame, "Executive", "Top 20 Calls", "Top 20 oldest calls by executive", "Share of Top 20 (%)")

    # Bottom-left is also scoped: franchise updates show technicians; executive view uses status
    # when they cover multiple franchises, or technician workload when they have a single franchise.
    ax_secondary = fig.add_axes([0.105, 0.295, 0.36, 0.19])
    if mode == "franchise":
        tech_frame = analysis.get("technician_summary", pd.DataFrame()).copy()
        draw_hbar(ax_secondary, tech_frame, "Technician", "Pending Tickets", "Technician follow-up workload")
    elif mode == "executive":
        if len(analysis["franchise_summary"]) > 1:
            status_frame = analysis["status_summary"].copy()
            draw_hbar(ax_secondary, status_frame, "Status", "Unique Tickets", "Your calls by status")
        else:
            tech_frame = analysis.get("technician_summary", pd.DataFrame()).copy()
            draw_hbar(ax_secondary, tech_frame, "Technician", "Pending Tickets", "Technician follow-up workload")
    else:
        fr_frame = analysis["franchise_summary"].copy()
        # This branch view includes only unique active pending tickets aged strictly more than 2 days.
        if not fr_frame.empty and "Aged >2 Days" in fr_frame.columns:
            fr_frame["Aged >2 Days"] = pd.to_numeric(fr_frame["Aged >2 Days"], errors="coerce").fillna(0)
            fr_frame = fr_frame.loc[fr_frame["Aged >2 Days"] > 0]
        draw_hbar(ax_secondary, fr_frame, "Franchise", "Aged >2 Days", "Franchise calls pending >2 days")

    ax_feedback = fig.add_axes([0.575, 0.295, 0.35, 0.19])
    csat_summary = analysis["csat_summary"].copy()
    if not csat_summary.empty:
        order = {"HAPPY": 0, "OK": 1, "NOT HAPPY": 2}
        csat_summary["_ord"] = csat_summary["Feedback"].map(lambda x: order.get(clean_text(x).upper(), 3))
        csat_summary = csat_summary.sort_values("_ord")
        labels = csat_summary["Feedback"].astype(str).str.upper().tolist()
        vals = pd.to_numeric(csat_summary["Share %"], errors="coerce").fillna(0).tolist()
        color_map = {"HAPPY": green, "OK": amber, "NOT HAPPY": red}
        bars = ax_feedback.bar(labels, vals, color=[color_map.get(x, "#8A9BA9") for x in labels], width=0.55)
        feedback_title = "Customer feedback mix" if mode == "branch" else "Customer feedback for this view"
        style_axis(ax_feedback, feedback_title)
        ax_feedback.set_ylim(0, max(100, max(vals, default=0) * 1.17))
        ax_feedback.tick_params(axis="x", labelsize=8.0, colors=ink, pad=5)
        ax_feedback.tick_params(axis="y", labelsize=7.8, colors=ink)
        ax_feedback.grid(axis="x", visible=False)
        for bar, val in zip(bars, vals):
            ax_feedback.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1.5,
                             f"{val:.1f}%", ha="center", va="bottom", fontsize=8.5, color=ink, weight="bold")
    else:
        ax_feedback.axis("off")
        title = "No customer feedback matched this view" if mode != "branch" and not analysis.get("csat_scope_supported", True) else "No Customer Satisfaction report uploaded for this view"
        ax_feedback.text(0.03, 0.5, title, transform=ax_feedback.transAxes, color=muted, fontsize=9, va="center")
        ax_feedback.set_title("Customer feedback", loc="left", color=navy, fontsize=11.2, fontweight="bold", pad=9)

    # Bottom information panel: readable line lengths with separate movement and data-quality columns.
    fig.patches.append(plt.Rectangle((0.04, 0.045), 0.92, 0.20, transform=fig.transFigure,
                                     facecolor="#FFFFFF", edgecolor="#D8E0E7", linewidth=1.0, zorder=0))
    fig.text(0.055, 0.222, "SNAPSHOT MOVEMENT", fontsize=8.8, color=teal, weight="bold", va="center")
    prev = analysis["previous_pending_report"]
    if prev:
        movement_text = (
            f"Newly present: {mc['new']:,}  ·  Continuing: {mc['continuing']:,}\n"
            f"No longer listed: {mc['missing']:,}  ·  Status changed: {mc['status_changed']:,}  ·  Age increased: {mc['age_increased']:,}"
        )
    else:
        movement_text = "Only one Pending Call snapshot was uploaded; hourly movement cannot yet be calculated."
    fig.text(0.055, 0.199, textwrap.fill(movement_text, width=78), fontsize=8.1, color=ink, va="top", linespacing=1.45)
    fig.text(0.055, 0.145, "A call absent from a later snapshot is not proof of closure.", fontsize=7.9, color=red, va="top")
    status_counts = analysis["status_summary"].head(4)
    status_line = "Status mix: " + "  ·  ".join(
        f"{clean_text(row['Status']) or 'Unspecified'} {int(row['Unique Tickets']):,}" for _, row in status_counts.iterrows()
    ) if not status_counts.empty else "Status mix: not available"
    fig.text(0.055, 0.118, textwrap.fill(status_line, width=80), fontsize=7.8, color=muted, va="top")

    fig.lines.append(plt.Line2D([0.655, 0.655], [0.065, 0.225], transform=fig.transFigure, color="#E0E6EB", linewidth=1.0))
    fig.text(0.675, 0.222, "DATA QUALITY & COVERAGE", fontsize=8.8, color=teal, weight="bold", va="center")
    dq = analysis["data_quality_metrics"]
    dq_text = (
        f"Missing executive: {dq['missing_executive']:,}  ·  Missing technician: {dq['missing_technician']:,}\n"
        f"Missing ticket ID: {dq['missing_ticket_number']:,}  ·  Extra source rows: {dq['rows_beyond_distinct_tickets']:,}\n"
        f"Excluded: {dq['soft_closed_tickets_excluded']:,} soft-closed + {dq['negative_response_tickets_excluded']:,} negative-response"
    )
    fig.text(0.675, 0.199, textwrap.fill(dq_text, width=57), fontsize=7.3, color=ink, va="top", linespacing=1.3)
    reg = analysis["registered_count"]
    if reg is not None:
        reg_line = f"Calls registered: {reg:,} distinct tickets ({analysis['registered_date_coverage']})."
        if analysis["closed_count"] is not None:
            reg_line += f" Closure timestamps: {analysis['closed_count']:,}."
    else:
        reg_line = "Calls registered for selected date: unavailable from the uploaded report period or scope."
    fig.text(0.675, 0.119, textwrap.fill(reg_line, width=57), fontsize=7.2, color=muted, va="top", linespacing=1.25)
    fig.text(0.96, 0.020, "INTERNAL WORKING REPORT  ·  Verify source coverage before formal management circulation",
             ha="right", va="center", fontsize=7.4, color="#435365")

    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=fig.get_facecolor())
    plt.close(fig)
    return buf.getvalue()


def make_pdf(priority_png: bytes, management_png: bytes) -> bytes:
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas
    from PIL import Image

    buf = io.BytesIO()
    page_size = landscape(A4)
    pdf = canvas.Canvas(buf, pagesize=page_size)
    page_w, page_h = page_size
    for img_bytes in [priority_png, management_png]:
        img = Image.open(io.BytesIO(img_bytes))
        iw, ih = img.size
        scale = min((page_w - 22) / iw, (page_h - 22) / ih)
        w, h = iw * scale, ih * scale
        x, y = (page_w - w) / 2, (page_h - h) / 2
        pdf.drawImage(ImageReader(img), x, y, width=w, height=h, preserveAspectRatio=True, mask="auto")
        pdf.showPage()
    pdf.save()
    return buf.getvalue()


def make_excel(analysis: Dict[str, Any]) -> bytes:
    """Create a polished, multi-sheet review workbook in memory."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter", datetime_format="dd-mmm-yyyy hh:mm", date_format="dd-mmm-yyyy") as writer:
        wb = writer.book
        navy = "#12304A"
        teal = "#148A8A"
        pale = "#EAF1F5"
        header_fmt = wb.add_format({"bold": True, "font_color": "white", "bg_color": navy, "text_wrap": True, "valign": "vcenter", "border": 0})
        title_fmt = wb.add_format({"bold": True, "font_size": 18, "font_color": navy})
        subtitle_fmt = wb.add_format({"font_color": "#5D6C7B", "font_size": 10})
        section_fmt = wb.add_format({"bold": True, "font_color": "white", "bg_color": teal, "font_size": 11})
        key_fmt = wb.add_format({"bold": True, "font_color": navy, "bg_color": pale, "border": 1, "border_color": "#D9E1E8"})
        val_fmt = wb.add_format({"bold": True, "font_size": 14, "font_color": navy, "border": 1, "border_color": "#D9E1E8", "align": "center"})
        note_fmt = wb.add_format({"text_wrap": True, "valign": "top", "font_color": "#465563"})

        overview = wb.add_worksheet("Management Summary")
        writer.sheets["Management Summary"] = overview
        overview.set_column("A:A", 31)
        overview.set_column("B:B", 30)
        overview.set_column("C:F", 18)
        overview.merge_range("A1:F1", "SERVICE OPERATIONS ANALYSIS", title_fmt)
        overview.merge_range("A2:F2", f"Hyderabad Branch · Analysis date {_date_label(analysis['analysis_date'])} · Snapshot {analysis['current_pending_report']['snapshot_dt'].strftime('%d %b %Y %H:%M')}", subtitle_fmt)
        overview.merge_range("A4:F4", "KEY METRICS", section_fmt)
        kpis = [
            ("Unique pending tickets", analysis["current_unique_tickets"]),
            ("Eligible rows in pending export", analysis["current_pending_rows"]),
            ("Pending aged 7+ days", analysis["older_7"]),
            ("Escalated tickets", analysis["escalated"]),
            ("Repeat-call flags", analysis["repeat_calls"]),
            ("Overdue scheduled calls", analysis["overdue_scheduled"]),
            ("Newly present vs previous snapshot", analysis["movement_counts"]["new"] if analysis["previous_pending_report"] else "N/A"),
            ("No longer listed vs previous snapshot", analysis["movement_counts"]["missing"] if analysis["previous_pending_report"] else "N/A"),
            ("Customer Satisfaction Score (CSS, exact)", f"{analysis['csat_metrics']['css_pct']:.2f}%" if analysis["csat_metrics"].get("css_pct") is not None else "N/A"),
            ("Customer Satisfaction Score (rounded for image)", f"{analysis['csat_metrics']['css_pct_rounded']}%" if analysis["csat_metrics"].get("css_pct_rounded") is not None else "N/A"),
            ("Happy feedback share (feedback mix only)", f"{analysis['csat_metrics']['happy_pct']:.2f}%" if analysis["csat_metrics"]["happy_pct"] is not None else "N/A"),
            ("Not-happy feedback share", f"{analysis['csat_metrics']['not_happy_pct']:.2f}%" if analysis["csat_metrics"]["not_happy_pct"] is not None else "N/A"),
            ("CSS formula", "(Happy count - Not Happy count) / total nonblank feedback responses × 100"),
            ("CSS change vs previous CSAT snapshot (percentage points)", f"{analysis['csat_movement']['css_delta_pp']:.2f}" if analysis['csat_movement'].get('css_delta_pp') is not None else "N/A"),
            ("Calls registered on analysis date", analysis["registered_count"] if analysis["registered_count"] is not None else "N/A"),
            ("Records with closure timestamp on date", analysis["closed_count"] if analysis["closed_count"] is not None else "N/A"),
        ]
        for idx, (key, val) in enumerate(kpis):
            row = 4 + idx
            overview.write(row, 0, key, key_fmt)
            overview.write(row, 1, val, val_fmt)
        overview.merge_range("D5:F5", "INTERPRETATION NOTES", section_fmt)
        notes = [
            "The 20-call list is sorted only by Days Old, highest to lowest. Equal-age calls retain their source order.",
            "Repeated ticket rows can reflect multiple component/spare details; ranking consolidates by Ticket No and aggregates those details.",
            "A ticket missing from a later pending export is not automatically labelled closed.",
            "The selected snapshot timestamp is taken from the filename when available; otherwise the date-range label is used and export time is unknown.",
            _snapshot_status(analysis),
        ]
        for i, note in enumerate(notes, start=6):
            overview.merge_range(i - 1, 3, i - 1, 5, note, note_fmt)
            overview.set_row(i - 1, 35)

        tables: List[Tuple[str, pd.DataFrame]] = []
        top_cols = [c for c in ["Order", "Ticket No", "Days Old", "Franchise Name", "Customer Name", "Service Executive Name", "Technician Name", "Call Type", "Status", "Executive % of Top 20", "Missing Executive", "Missing Technician", "Source Row Count", "Spare", "SpareDesc", "Additive", "AdditiveDesc", "Accessories", "AccessoriesDesc"] if c in analysis["top20"].columns]
        tables.append(("20 Oldest Calls", analysis["top20"][top_cols].copy()))
        tables.append(("Top 20 by Executive", analysis.get("top20_executive_summary", pd.DataFrame()).copy()))
        tables.append(("Current Pending", analysis["priorities"].copy()))
        tables.append(("Snapshot Comparison", analysis["comparison"].copy()))
        tables.append(("Backlog by Franchise", analysis["franchise_summary"].copy()))
        tables.append(("Executive Workload", analysis["executive_summary"].copy()))
        tables.append(("Ageing Summary", analysis["age_summary"].copy()))
        tables.append(("Status Summary", analysis["status_summary"].copy()))
        tables.append(("CSAT Summary", analysis["csat_summary"].copy()))
        tables.append(("CSAT Snapshot Comparison", analysis["csat_comparison"].copy()))
        tables.append(("Data Quality", analysis["data_quality"].copy()))

        if not analysis["registered"].empty:
            tables.append(("Calls Registered", analysis["registered"].copy()))
        else:
            tables.append(("Calls Registered", pd.DataFrame([{"Note": "No Calls Registered report uploaded."}])))
        if not analysis["csat"].empty:
            csat = analysis["csat"]
            chosen_cols = [find_col(csat, [alias]) for alias in ["TicketNo", "Call Type", "Status", "Closed Date", "FrName", "Technician Name", "Branch Exe Name", "Description", "FeedBack", "FeedBack Date"]]
            chosen_cols = [c for c in chosen_cols if c]
            tables.append(("CSAT Feedback Detail", csat[chosen_cols].copy()))

        source_rows = []
        for r in analysis["reports"]:
            source_rows.append({
                "File": r["filename"], "Detected type": r["report_type"], "Source rows": r["rows"],
                "Period": r["metadata"], "Snapshot / sort time": r["snapshot_dt"], "Timestamp basis": r["snapshot_source"],
            })
        tables.append(("Source Files", pd.DataFrame(source_rows)))

        for sheet_name, df in tables:
            # Excel tab name limit is 31 chars; names above fit.
            df = df.copy()
            df.to_excel(writer, sheet_name=sheet_name, index=False, startrow=0)
            ws = writer.sheets[sheet_name]
            ws.freeze_panes(1, 0)
            if len(df.columns):
                ws.autofilter(0, 0, max(1, len(df)), len(df.columns) - 1)
                for col_num, col in enumerate(df.columns):
                    vals = df[col].head(500).map(clean_text).tolist() if not df.empty else []
                    max_len = max([len(clean_text(col))] + [min(len(v), 45) for v in vals])
                    width = min(max(max_len + 2, 11), 38)
                    if norm(col) in {"customername", "suggestednextaction", "franchisename", "technicianname", "serviceexecutivename", "note"}:
                        width = min(max(width, 24), 42)
                    ws.set_column(col_num, col_num, width)
                for col_num, col in enumerate(df.columns):
                    ws.write(0, col_num, col, header_fmt)
                ws.set_row(0, 30)
    buf.seek(0)
    return buf.getvalue()
