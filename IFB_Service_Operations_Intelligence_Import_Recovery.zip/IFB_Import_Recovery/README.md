# IFB Service Operations Intelligence — import recovery package

This package resolves the Streamlit Cloud import mismatch by changing the engine module name to `service_ops_engine_v3.py`, so the app no longer tries to import `scope_analysis` from a stale `service_ops_engine.py` module.

## Deploy on GitHub

1. Extract this ZIP.
2. Upload `app.py`, `service_ops_engine_v3.py`, `requirements.txt`, and `.streamlit/config.toml` into the repository root / matching folder. Commit the change to the branch configured in Streamlit Community Cloud.
3. The previous `service_ops_engine.py` may remain in the repository; this app version no longer imports it.
4. In Streamlit Community Cloud, reboot the app if it does not redeploy automatically.

Do not upload company reports to a public repository. Use company-approved hosting for actual confidential data.
